tinyMCE.addI18n('en.wordpress_form_manager_dlg',{
	label:"Select form",
	desc:"Insert form",
});