=== Rembrandt ===
Author: Tomasz Mazur
Tags: white, light blue, red, pink, orange, green, gold, theme-options, editor-style, two-columns, right-sidebar, custom-background, custom-menu,
Requires at least: WP 3.1

== Description ==
Minimalistic two-columns, fixed-width,  seo optimized  theme for WordPress. Compatible with WordPress 3.1 features, valid XHTML & CSS, mobile version, custom widgets(Twitter, Flickr, About us). Recomendet plugins (WordPress SEO, Contact Form 7).
Rembrandt theme includes support for the following languages:
* English
* Polish

== Theme Features ==
Custom Widgets
Localization Support
Cross-browser compatibility
Threaded Comments
Gravatar ready
Custom background
Custom header
Styles
...